from django import forms
from .models import Bookings, UserProfile
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms.widgets import DateTimeInput, TextInput
#from bootstrap_datepicker_plus.widgets import DateTimePickerInput

class BookingForm(forms.ModelForm):
  class Meta:
    model = Bookings
    fields = ['start_time', 'end_time', 'organizer_name', 'purpose',
               'expected_participants', 'needs_projector']
    widgets = {
      'start_time': DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
      'end_time': DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
      'organizer_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Organizator'}),
      'purpose': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Svrha'}),
      'expected_participants': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Očekivani broj učesnika (arapskim ciframa)'}),
      'needs_projector': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    }
    labels = {
      'start_time': 'Početak termina',
      'end_time': 'Kraj termina',
      'organizer_name': 'Organizator',
      'purpose': 'Svrha',
      'expected_participants': 'Očekivani broj učesnika',
      'needs_projector': 'Potreban projektor',
    }


class RegistrationForm(UserCreationForm):

  class Meta:
    model = User
    fields = ['username', 'password1', 'password2', 'first_name',
               'last_name', 'email']
    widgets = {
      'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'odaberi korisničko ime'}),
      'password1': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}),
      'password2': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password2'}),
      'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ime'}),
      'last_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Prezime'}),
      'email': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),
    }
    labels = {
        'password2': 'Potvrda passworda',
      }


class UserProfileForm(forms.ModelForm):
  #telephone_number = forms.CharField(max_length=15, required=True)
  #medical_title = forms.CharField(max_length=100, required=False)

  class Meta:
    model = UserProfile
    fields = ['telephone_number', 'medical_title']
    
    widgets = {
      'telephone_number': TextInput(attrs={'class': 'form-control', 'placeholder': 'Broj telefona'}),
      'medical_title': TextInput(attrs={'class': 'form-control', 'placeholder': 'Medicinska titula'}),
    }
    labels = {
      'telephone_number': 'Broj telefona',
      'medical_title': 'Medicinska titula',
    }
